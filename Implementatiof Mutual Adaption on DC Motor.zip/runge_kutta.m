function x_new =runge_kutta(h,func,x,t,u,a,b)
   
    k_1 = h*func(x,t,u,a,b);
    k_2 = h*func((x+0.5*k_1),(t+0.5*h),u,a,b);
    k_3 = h*func((x+0.5*k_2),(t+0.5*h),u,a,b);
    k_4 = h*func((x+k_3),(t+h),u,a,b);
    x_new= x +(1/6)*(k_1+2*k_2+2*k_3+k_4);

end
