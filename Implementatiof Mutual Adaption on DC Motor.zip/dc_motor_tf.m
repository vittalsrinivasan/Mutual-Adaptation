clc;
clear all;
close all;
R = 2.0;                % Ohms
L = 0.5;                % Henrys
Km = 0.1;               % torque constant
Kb = 0.1;               % back emf constant
Kf = 0.2;               % Nms
J = 0.02;               % kg.m^2/s^2
h=0.1;
t = 0:h:10;

h1 = tf(Km,[L R]);            % armature
h2 = tf(1,[J Kf]);            % eqn of motion

dcm = ss(h2) * [h1 , 1];      % w = h2 * (h1*Va + Td)
dcm = feedback(dcm,Kb,1,1);   % close back emf loop

stepplot(dcm(1));
grid on
set(gcf,'color','w');
x1 =[zeros(1,length(t));zeros(1,length(t))];
x1(:,1)=[1;10];
u1=10;
for i=1:(length(t)-1)
    x1(:,i+1)=runge_kutta(h,@func1,x1(:,i),t(i),u1,dcm.A,dcm.B(:,2));
end

T=(0:length(t)-1);

figure
plot(x1(1,:),'LineWidth',1.5);
title('speed')
grid on
xlabel( 'Time (0.1s)')
ylabel('Amplitude')
set(gcf,'color','w');
figure
plot(x1(2,:),'LineWidth',1.5);
title('armature current')
grid on
xlabel( 'Time (0.1s)')
ylabel('Amplitude')
set(gcf,'color','w');