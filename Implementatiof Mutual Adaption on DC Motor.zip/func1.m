function xcap=func1(x,t,u,a,b)
 a=reshape(a,[2,2]);
xcap=(a*x)+(b*u);
end
