load('E:\CIS\dc motor\MA for DC\DC_vals.mat')
T = 0:0.01:20;
%{
subplot(1,2,1)
plot(T,x1(1,:),T,x2(1,:),'LineWidth',3)
xlim([0,5])
%ylim([2,11])
grid on
title('(a)','FontSize',23,'FontWeight','bold')
xlabel('Time (sec)','FontSize',23,'FontWeight','bold')
ylabel('Amplitude','FontSize',23,'FontWeight','bold')
set(findobj(gcf,'type','axes'),'FontSize',23,'FontWeight','bold','LineWidth',2);
legend('x_1_1(t)','x_2_1(t)','location','northeast')
%print(figure(1),'SP_x1.png','-dpng','-r300');

subplot(1,2,2)
plot(T,x1(2,:),T,x2(2,:),'LineWidth',3);
xlim([0,5])
%ylim([2,11])
grid on
title('(b)','FontSize',23,'FontWeight','bold')
xlabel('Time (sec)','FontSize',23,'FontWeight','bold')
ylabel('Amplitude','FontSize',23,'FontWeight','bold')
set(findobj(gcf,'type','axes'),'FontSize',23,'FontWeight','bold','LineWidth',2);
legend('x_1_2(t)','x_2_2(t)','location','northeast')
%print(figure(1),'SP_x2.png','-dpng','-r300');
%}
%{
subplot(1,2,1)
plot(T,e(1,:),'-r','LineWidth',3);
xlim([0,5])
grid on
title('(a)','FontSize',23,'FontWeight','bold')
xlabel('Time (sec)','FontSize',23,'FontWeight','bold')
ylabel('Amplitude','FontSize',23,'FontWeight','bold')
set(findobj(gcf,'type','axes'),'FontSize',23,'FontWeight','bold','LineWidth',2);
%legend('x_1(t)','x_2(t)','location','northeast')
%print(figure(1),'SP_error.png','-dpng','-r300');

subplot(1,2,2)
plot(T,e(2,:),'-r','LineWidth',3);
xlim([0,5])
ylim([-2,2])
grid on
title('(b)','FontSize',23,'FontWeight','bold')
xlabel('Time (sec)','FontSize',23,'FontWeight','bold')
ylabel('Amplitude','FontSize',23,'FontWeight','bold')
set(findobj(gcf,'type','axes'),'FontSize',23,'FontWeight','bold','LineWidth',2);
%legend('x_1(t)','x_2(t)','location','northeast')
%}

subplot(2,2,1)
plot(T,a1(1,:),'-g',T,a2(1,:),'-k','LineWidth',3)
grid on
xlim([0 5])
title('(a)','FontSize',21,'FontWeight','bold')
xlabel('Time (sec)','FontSize',21,'FontWeight','bold')
ylabel('Amplitude','FontSize',21,'FontWeight','bold')
set(findobj(gcf,'type','axes'),'FontSize',21,'FontWeight','bold','LineWidth',2);
legend('a_1_1(t)','a_2_1(t)','location','northeast','FontSize',12)

subplot(2,2,2)
plot(T,a1(2,:),'-g',T,a2(2,:),'-k','LineWidth',3)
xlim([0 5])
grid on
title('(b)','FontSize',21,'FontWeight','bold')
xlabel('Time (sec)','FontSize',21,'FontWeight','bold')
ylabel('Amplitude','FontSize',21,'FontWeight','bold')
set(findobj(gcf,'type','axes'),'FontSize',21,'FontWeight','bold','LineWidth',2);
legend('a_1_2(t)','a_2_2(t)','location','northeast','FontSize',12)
%print(figure(1),'SP_para1.png','-dpng','-r300');

subplot(2,2,3)
plot(T,a1(3,:),'-g',T,a2(3,:),'-k','LineWidth',3)
grid on
xlim([0 5])
title('(c)','FontSize',21,'FontWeight','bold')
xlabel('Time (sec)','FontSize',21,'FontWeight','bold')
ylabel('Amplitude','FontSize',21,'FontWeight','bold')
set(findobj(gcf,'type','axes'),'FontSize',21,'FontWeight','bold','LineWidth',2);
legend('a_1_3(t)','a_2_3(t)','location','northeast','FontSize',12)

subplot(2,2,4)
plot(T,a1(4,:),'-g',T,a2(4,:),'-k','LineWidth',3)
grid on
xlim([0 5])
title('(d)','FontSize',21,'FontWeight','bold')
xlabel('Time (sec)','FontSize',21,'FontWeight','bold')
ylabel('Amplitude','FontSize',21,'FontWeight','bold')
set(findobj(gcf,'type','axes'),'FontSize',21,'FontWeight','bold','LineWidth',2);
legend('a_1_4(t)','a_2_4(t)','location','northeast','FontSize',12)
%print(figure(1),'SP_para2.png','-dpng','-r300');

