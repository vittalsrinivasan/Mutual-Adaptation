clc;
clear all;
close all;
%system 1
R1 = 3.0;                % Ohms
L1 = 0.5;                % Henrys
Km1 = 0.3;               % torque constant
Kb1 = 0.1;               % back emf constant
Kf1 = 0.2;               % Nms
J1 = 0.02;               % kg.m^2/s^2
%system 2
R2 = 4.0;                % Ohms
L2 = 0.75;                % Henrys
Km2 = 0.5;               % torque constant
Kb2 = 0.4;               % back emf constant
Kf2 = 0.6;               % Nms
J2= 0.07;
h=0.01;
t = 0:h:20;
%step resp system 1
h1 = tf(Km1,[L1 R1]);            % armature
h2 = tf(1,[J1 Kf1]);            % eqn of motion

dcm1 = ss(h2) * [h1 , 1];      % w = h2 * (h1*Va + Td)
dcm1 = feedback(dcm1,Kb1,1,1);   % close back emf loop
figure
stepplot(dcm1(1));
grid on
set(gcf,'color','w');
%step resp system 2
k1 = tf(Km2,[L2 R2]);            % armature
k2 = tf(1,[J2 Kf2]);            % eqn of motion

dcm2 = ss(k2) * [k1 , 1];      % w = h2 * (h1*Va + Td)
dcm2 = feedback(dcm2,Kb2,1,1);   % close back emf loop
figure
stepplot(dcm2(1));
grid on
set(gcf,'color','w');
x1 =[zeros(1,length(t));zeros(1,length(t))];
x1(:,1)=[5;15];

x2 =[zeros(1,length(t));zeros(1,length(t))];
x2(:,1)=[6;12];

a1 =[[zeros(1,length(t)); zeros(1,length(t));zeros(1,length(t));zeros(1,length(t))]];
a2 =[[zeros(1,length(t)); zeros(1,length(t));zeros(1,length(t));zeros(1,length(t))]];
a_1=reshape(dcm1.A,[4,1]);
a1(:,1)=a_1;
a_2=reshape(dcm2.A,[4,1]);
a2(:,1)=a_2;
%u1=sin(0.25*t);
%u2=sin(0.25*t);

e =[zeros(1,length(t));zeros(1,length(t))];
e(:,1)=x1(:,1)-x2(:,1);

for i=1:(length(t)-1)
    u1(i)=70;
    u2(i)=70;
    x1(:,i+1)=runge_kutta(h,@func1,x1(:,i),t(i),u1(i),a1(:,i),dcm1.B(:,1));
    x2(:,i+1)=runge_kutta(h,@func1,x2(:,i),t(i),u2(i),a2(:,i),dcm2.B(:,1));
    e(:,i+1)=x1(:,i+1)-x2(:,i+1);
    a1(:,i+1)=runge_kutta(h,@func3,a1(:,i),t(i),e(:,i+1),x1(:,i+1),dcm1.B(:,1));
    a2(:,i+1)=runge_kutta(h,@func2,a2(:,i),t(i),e(:,i+1),x2(:,i+1),dcm2.B(:,1));
end

T=(0:length(t)-1);
figure
plot(T,x1(1,:),T,x2(1,:),'LineWidth',1.5);
grid on
xlim([0,500])
title('Armature Current');
legend('x1','x2');
set(gcf,'color','w');
xlabel( 'Time (0.01s)')
ylabel('Amplitude')
figure
plot(T,x1(2,:),T,x2(2,:),'LineWidth',1.5);
xlim([0,500])
title('Speed');
legend('x1','x2');
set(gcf,'color','w');
xlabel( 'Time (0.01s)')
ylabel('Amplitude')
grid on

figure
set(gcf,'color','w');
subplot(3,1,1)
grid on
plot(T,x1,'LineWidth',1.5);
title('Output for subsystem 1 (x1)')
xlabel( 'Time (0.01s)')
ylabel('Amplitude')
subplot(3,1,2)
plot(T,x2,'LineWidth',1.5);
grid on
title('Output for subsystem 2 (x2)')
xlabel( 'Time (0.01s)')
ylabel('Amplitude')
subplot(3,1,3)
plot(T,e,'LineWidth',1.5);
grid on
title('Error e')
xlabel( 'Time (0.01s)')
ylabel('Amplitude')

figure
set(gcf,'color','w');
subplot(4,1,1)
plot(T,a1(1,:),'-g',T,a2(1,:),'-k','LineWidth',1.5)
grid on
title('Adaptation of a11 and a21')
xlabel( 'Time (0.01s)')
ylabel('Amp')
legend('a11','a21')


subplot(4,1,2)
plot(T,a1(2,:),'-g',T,a2(2,:),'-k','LineWidth',1.5)
grid on
title('Adaptation of a12 and a22')
xlabel( 'Time (0.01s)')
ylabel('Amp')
legend('a12','a22')

subplot(4,1,3)
plot(T,a1(3,:),'-g',T,a2(3,:),'-k','LineWidth',1.5)
grid on
title('Adaptation of a13 and a23')
xlabel( 'Time (0.01s)')
ylabel('Amp')
legend('a13','a23')

subplot(4,1,4)
plot(T,a1(4,:),'-g',T,a2(4,:),'-k','LineWidth',1.5)
grid on
title('Adaptation of a14 and a24')
xlabel( 'Time (0.01s)')
ylabel('Amp')
legend('a14','a24')
a_1f=reshape(a1(:,1001),[2,2]);
a_2f=reshape(a2(:,1001),[2,2]);
eig(a_1f)
eig(a_2f)