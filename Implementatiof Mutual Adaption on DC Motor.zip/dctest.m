clc
close all
clear all
J1 = 0.1; %Moment of inertia of rotor
B1 = 1; %Viscous frictional constant
K1 = 0.1;%torque constant
R1 = 10; %Resistance of armature winding
L1 = 5; %inductance of armature winding 

J2 = 0.2;
B2 = 2;
K2 = 0.2;
R2 = 20;
L2 = 10;

h=0.01; % step size
t = 0:h:10; 
a1 =[[zeros(1,length(t)); zeros(1,length(t));zeros(1,length(t));zeros(1,length(t))]];
a2 =[[zeros(1,length(t)); zeros(1,length(t));zeros(1,length(t));zeros(1,length(t))]];
a1(:,1)=[-B1/J1;K1/J1;-K1/L1;-R1/L1];
x1 =[zeros(1,length(t));zeros(1,length(t))];
x1(:,1)=[1;10];
b1=[0;1\L1];
a2(:,1)=[-B2/J2;K2/J2;-K2/L2 ;-R2/L2];
x2 =[zeros(1,length(t));zeros(1,length(t))];
x2(:,1)=[2;20];
b2=[0;1\L2];

e =[zeros(1,length(t));zeros(1,length(t))];
e(:,1)=x1(:,1)-x2(:,1);

%u=12; 
u1 =[zeros(1,length(t))];%zeros(1,length(t))];
u2 =[zeros(1,length(t))];%zeros(1,length(t))];
%u =50*square(t);
for i=1:(length(t)-1)
    u1(:,i)=10;%;10];
    u2(:,i)=10;%;10];
    x1(:,i+1)=runge_kutta(h,@func1,x1(:,i),t(i),u1(i),a1(:,i),b1);
    x2(:,i+1)=runge_kutta(h,@func1,x2(:,i),t(i),u2(i),a2(:,i),b2);
    e(:,i+1)=x1(:,i+1)-x2(:,i+1);
    a1(:,i+1)=runge_kutta(h,@func3,a1(:,i),t(i),e(:,i+1),x1(:,i+1),b1);
    a2(:,i+1)=runge_kutta(h,@func2,a2(:,i),t(i),e(:,i+1),x2(:,i+1),b2);
end

T=(0:length(t)-1);
figure
plot(x1(1,:),x1(2,:));
title('current vs speed');

%{
figure
plot(T,x1(1,:),T,x2(1,:));
title('armature current')
legend('x1','x2');
%}
figure
plot(T,x1(2,:),T,x2(2,:));
title('speed');
legend('x1','x2');


figure
subplot(3,1,1)
plot(T,x1);
title('Output for subsystem 1 (x1)')
xlabel( 'Time (0.01s)')
ylabel('Amplitude')
subplot(3,1,2)
plot(T,x2);
title('Output for subsystem 2 (x2)')
xlabel( 'Time (0.01s)')
ylabel('Amplitude')
subplot(3,1,3)
plot(T,e);
title('Error e')
xlabel( 'Time (0.01s)')
ylabel('Amplitude')



figure
subplot(4,1,1)
plot(T,a1(1,:),'-g',T,a2(1,:),'-k')
title('Adaptation of a11 and a21')
xlabel( 'Time (0.01s)')
ylabel('Amp')
legend('a11','a21')


subplot(4,1,2)
plot(T,a1(2,:),'-g',T,a2(2,:),'-k')
title('Adaptation of a12 and a22')
xlabel( 'Time (0.01s)')
ylabel('Amp')
legend('a12','a22')

subplot(4,1,3)
plot(T,a1(3,:),'-g',T,a2(3,:),'-k')
title('Adaptation of a13 and a23')
xlabel( 'Time (0.01s)')
ylabel('Amp')
legend('a13','a23')

subplot(4,1,4)
plot(T,a1(4,:),'-g',T,a2(4,:),'-k')
title('Adaptation of a14 and a24')
xlabel( 'Time (0.01s)')
ylabel('Amp')
legend('a14','a24')



