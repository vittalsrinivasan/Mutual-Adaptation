close all;
load('E:\CIS\simple pendulum\MA For Simple Pendulum\SP_vals.mat')

subplot(1,2,1)
plot(T,x1(1,:),T,x2(1,:),'LineWidth',1.5)
%xlim([0,120])
%ylim([2,11])
grid on
title('(a)','FontSize',12,'FontWeight','bold')
xlabel('Time','FontSize',12,'FontWeight','bold')
ylabel('Amplitude','FontSize',12,'FontWeight','bold')
set(findobj(gcf,'type','axes'),'FontSize',12,'FontWeight','bold','LineWidth',1);
legend('x_1_1(t)','x_2_1(t)','location','northeast')
%print(figure(1),'SP_x1.png','-dpng','-r300');

subplot(1,2,2)
plot(T,x1(2,:),T,x2(2,:),'LineWidth',1.5);
%xlim([0,120])
%ylim([2,11])
grid on
title('(b)','FontSize',12,'FontWeight','bold')
xlabel('Time','FontSize',12,'FontWeight','bold')
ylabel('Amplitude','FontSize',12,'FontWeight','bold')
set(findobj(gcf,'type','axes'),'FontSize',12,'FontWeight','bold','LineWidth',1);
legend('x_1_2(t)','x_2_2(t)','location','northeast')
%print(figure(1),'SP_x2.png','-dpng','-r300');
%{
subplot(1,2,1)
plot(T,e(1,:),'LineWidth',1.5);
%xlim([0,120])

grid on
title('(a)','FontSize',12,'FontWeight','bold')
xlabel('Time','FontSize',12,'FontWeight','bold')
ylabel('Amplitude','FontSize',12,'FontWeight','bold')
set(findobj(gcf,'type','axes'),'FontSize',12,'FontWeight','bold','LineWidth',1);
%legend('x_1(t)','x_2(t)','location','northeast')
%print(figure(1),'SP_error.png','-dpng','-r300');
subplot(1,2,2)
plot(T,e(2,:),'LineWidth',1.5);
ylim([-2,2])
grid on
title('(b)','FontSize',12,'FontWeight','bold')
xlabel('Time','FontSize',12,'FontWeight','bold')
ylabel('Amplitude','FontSize',12,'FontWeight','bold')
set(findobj(gcf,'type','axes'),'FontSize',12,'FontWeight','bold','LineWidth',1);
%legend('x_1(t)','x_2(t)','location','northeast')


subplot(2,2,1)
plot(T,a1(1,:),'-g',T,a2(1,:),'-k','LineWidth',1.5)
grid on
title('(a)','FontSize',12,'FontWeight','bold')
xlabel('Time','FontSize',12,'FontWeight','bold')
ylabel('Amplitude','FontSize',12,'FontWeight','bold')
set(findobj(gcf,'type','axes'),'FontSize',12,'FontWeight','bold','LineWidth',1);
legend('a_1_1(t)','a_2_1(t)','location','northeast')

subplot(2,2,2)
plot(T,a1(2,:),'-g',T,a2(2,:),'-k','LineWidth',1.5)
grid on
title('(b)','FontSize',12,'FontWeight','bold')
xlabel('Time','FontSize',12,'FontWeight','bold')
ylabel('Amplitude','FontSize',12,'FontWeight','bold')
set(findobj(gcf,'type','axes'),'FontSize',12,'FontWeight','bold','LineWidth',1);
legend('a_1_2(t)','a_2_2(t)','location','northeast')
%print(figure(1),'SP_para1.png','-dpng','-r300');

subplot(2,2,3)
plot(T,a1(3,:),'-g',T,a2(3,:),'-k','LineWidth',1.5)
grid on
title('(c)','FontSize',12,'FontWeight','bold')
xlabel('Time','FontSize',12,'FontWeight','bold')
ylabel('Amplitude','FontSize',12,'FontWeight','bold')
set(findobj(gcf,'type','axes'),'FontSize',12,'FontWeight','bold','LineWidth',1);
legend('a_1_3(t)','a_2_3(t)','location','northeast')

subplot(2,2,4)
plot(T,a1(4,:),'-g',T,a2(4,:),'-k','LineWidth',1.5)
grid on
title('(d)','FontSize',12,'FontWeight','bold')
xlabel('Time','FontSize',12,'FontWeight','bold')
ylabel('Amplitude','FontSize',12,'FontWeight','bold')
set(findobj(gcf,'type','axes'),'FontSize',12,'FontWeight','bold','LineWidth',1);
legend('a_1_4(t)','a_2_4(t)','location','northeast')
%print(figure(1),'SP_para2.png','-dpng','-r300');
%}