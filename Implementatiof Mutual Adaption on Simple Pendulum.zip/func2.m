function acap=func2(a,t,e,x,b)
acap=e*x';
acap=reshape(acap,[4,1]);
end
