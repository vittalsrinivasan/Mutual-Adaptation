clc;
clear all;
close all;
h=0.01; % step size
t = 0:h:20;                                      
x1 =[zeros(1,length(t));zeros(1,length(t))]; 
u1 =[zeros(1,length(t))];
a1 =([zeros(1,length(t)); zeros(1,length(t));zeros(1,length(t));zeros(1,length(t))]);     
a2 =([zeros(1,length(t)); zeros(1,length(t));zeros(1,length(t));zeros(1,length(t))]); 
e =[zeros(1,length(t));zeros(1,length(t))];

gValue1 = 9.81;
rValue1 = 2;
m1=1;
w1 = -(gValue1/rValue1);
% initial condition
x1(:,1) = [0.2*pi;5] ;
a1(:,1)=[0;w1;1;0];
b1=[1;1/(m1*(rValue1^2))];
x2 =[zeros(1,length(t));zeros(1,length(t))]; 
u2 =[zeros(1,length(t))];
gValue2 = 9.81;
rValue2 = 8;
w2 = -(gValue2/rValue2);
% initial condition
m2=2;
x2(:,1) = [0.5*pi;6] ;
a2(:,1)=[0;w2;1;0];
b2=[1;1/(m2*(rValue2^2))];
c=[1,0];
a_1=a1(:,1);
a_1=reshape(a_1,[2,2])
a_2=a2(:,1);
a_2=reshape(a_2,[2,2])

for i=1:(length(t)-1)% calculation loop
   u1(i)= 10;
   u2(i)= 10;
    x1(:,i+1)=runge_kutta(h,@func1, x1(:,i),t(i),u1(i),a1(:,i),b1);
    x2(:,i+1)=runge_kutta(h,@func1, x2(:,i),t(i),u2(i),a2(:,i),b2);
    e(:,i+1)=x1(:,i+1)-x2(:,i+1);
    a1(:,i+1)=runge_kutta(h,@func3,a1(:,i),t(i),e(:,i+1),x1(:,i+1),0);
    a2(:,i+1)=runge_kutta(h,@func2,a2(:,i),t(i),e(:,i+1),x2(:,i+1),0);
end

T=(0:length(t)-1);
figure
set(gcf,'color','w');
plot(T,x1(1,:),T,x2(1,:),'LineWidth',1.5);
grid on;
title('Adaptation of \theta');
xlabel('Time (0.1s)');
ylabel('\theta/\pi');
legend('x1','x2')
figure
set(gcf,'color','w');
plot(T,x1(2,:),T,x2(2,:),'LineWidth',1.5);
grid on;
title('Adaptation of \theta dot');
xlabel('Time (0.1s)');
ylabel('Amp');
legend('x1','x2')
figure
set(gcf,'color','w');
subplot(4,1,1)
plot(T,a1(1,:),'-g',T,a2(1,:),'-k','LineWidth',1.5)
grid on;
title('Adaptation of a11 and a21')
xlabel( 'Time (0.1s)')
ylabel('Amp')
legend('a11','a21')


subplot(4,1,2)
plot(T,a1(2,:),'-g',T,a2(2,:),'-k','LineWidth',1.5)
grid on;
title('Adaptation of a12 and a22')
xlabel( 'Time (0.1s)')
ylabel('Amp')
legend('a12','a22')

subplot(4,1,3)
plot(T,a1(3,:),'-g',T,a2(3,:),'-k','LineWidth',1.5)
grid on;
title('Adaptation of a13 and a23')
xlabel( 'Time (0.1s)')
ylabel('Amp')
legend('a13','a23')

subplot(4,1,4)
plot(T,a1(4,:),'-g',T,a2(4,:),'-k','LineWidth',1.5)
grid on;
title('Adaptation of a14 and a24')
xlabel( 'Time (0.1s)')
ylabel('Amp')
legend('a14','a24')
figure
set(gcf,'color','w');

subplot(3,1,1)
plot(T,x1);
grid on
title('Output for subsystem 1 (x1)')
xlabel( 'Time (0.1s)')
ylabel('Amplitude')

subplot(3,1,2)
plot(T,x2);
grid on
title('Output for subsystem 2 (x2)')
xlabel( 'Time (0.1s)')
ylabel('Amplitude')

subplot(3,1,3)
plot(T,e);
grid on
title('Error e')
xlabel( 'Time (0.1s)')
ylabel('Amplitude')


a11=reshape(a1(:,201),[2,2]);
a22=reshape(a2(:,201),[2,2]); 
eig(a11)
eig(a22)
