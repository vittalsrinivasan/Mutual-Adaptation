function acap=func3(a,t,e,x)
acap=-e*x;
end
