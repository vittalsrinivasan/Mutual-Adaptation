function finalres (a1,x1,a2,x2,b)
[num1,denom1]=ss2tf([a1(5001)],[b],[b],0);
[num2,denom2]=ss2tf([a2(5001)],[b],[b],0);
sys1=tf(num1,denom1);
sys2=tf(num2,denom2);
disp('overall system TF:')
res=sys1-sys2

disp('poles of overall system:')
p=pole(res)
disp('zeros of overall system')
z=zero(res)
[num,denom]=tfdata(res,"v");

[a,b,c,d]=tf2ss(num,denom);
disp('eigen values of overall system:')
e=eig(a)
disp('freq response of overall system')
[Gm,Pm,Wcg,Wcp]=margin(res)

w=logspace(-1,1);
h = freqs(num,denom,w);
mag = abs(h);
phase = angle(h);
phasedeg = phase*180/pi;
subplot(2,1,1)
loglog(w,mag)
grid on
xlabel('Frequency (rad/s)')
ylabel('Magnitude')

subplot(2,1,2)
semilogx(w,phasedeg)
grid on
xlabel('Frequency (rad/s)')
ylabel('Phase (degrees)')


end