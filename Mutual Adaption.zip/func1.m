function xcap=func1(x,t,u,a)
b=1;
xcap=(a*x)+(b*u);
end
