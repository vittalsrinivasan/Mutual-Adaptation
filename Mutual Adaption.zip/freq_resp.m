function freq_resp(a,x,b)
[num,denom]=ss2tf([a(5001)],[b],[b],0);
disp('TF of subsystem:')
s=tf(num,denom)
disp('eigen values of subsystem:')
e=eig(a(5001))
disp('Freq response of subsystem')
[Gm,Pm,Wcg,Wcp]=margin(s)
disp('pole location of subsystem:')
p=pole(s)
disp('zero location of subsystem:')
z=zero(s)
w=logspace(-1,1);
h = freqs(num,denom,w);
mag = abs(h);
phase = angle(h);
phasedeg = phase*180/pi;

subplot(2,1,1)
loglog(w,mag)
grid on
xlabel('Frequency (rad/s)')
ylabel('Magnitude')

subplot(2,1,2)
semilogx(w,phasedeg)
grid on
xlabel('Frequency (rad/s)')
ylabel('Phase (degrees)')
end