function acap=func2(a,t,e,x)
acap=e*x;
end
