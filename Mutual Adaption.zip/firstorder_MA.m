clc;
clear all;
%close all;

h=0.01; % step size
t = 0:h:20;                                      
x1 =zeros(1,length(t)); 
x2 =zeros(1,length(t)); 
a1 =zeros(1,length(t)); 
a2 =zeros(1,length(t)); 
e =zeros(1,length(t));
mse=zeros(1,length(t));
u =zeros(1,length(t));
% initial condition
x1(1) =1; 
x2(1)=2;
a1(1)=1.5;
a2(1)=1.75;

e(1)=x1(1)-x2(1);
%u=sin(t);
%u=sin(4*t)+sin(5*t);
%u=exp(-5*t);

square_error=0;
counter=0;

for i=1:(length(t)-1)% calculation loop
    u(i)=20;
    x1(i+1)=runge_kutta(h,@func1, x1(i),t(i),u(i),a1(i));
    x2(i+1)=runge_kutta(h,@func1, x2(i),t(i),u(i),a2(i));
    e(i+1)=x1(i+1)-x2(i+1);
    square_error=square_error+(e(i+1))^2;
    counter=counter+1;
    mse(i)=square_error/counter;
    %disp(mse(i))
    a1(i+1)=runge_kutta(h,@func3,a1(i),t(i),e(i+1),x1(i+1));
    a2(i+1)=runge_kutta(h,@func2,a2(i),t(i),e(i+1),x2(i+1));
    
end
%{
%mse=square_error/counter;
disp('Mean square error:')
disp(mse(5000));
freq_resp(a1,x1,1);
title('Frequency response for subsystem 1 (x1)')
figure
freq_resp(a2,x2,1);
title('Frequency response for subsystem 2 (x2)')
figure
finalres(a1,x1,a2,x2,1);
title('Frequency response for Overall System')


T=(0:length(t)-1);

figure
plot(T,mse);
title('MSE vs Time')
xlabel( 'Time (0.01s)')
ylabel('Amplitude')
%}
T=(0:length(t)-1);
figure
plot(T,x1,T,x2,'LineWidth',1.5)
title('x1(t) vs x2(t)')
xlabel( 'x1(t)')
ylabel('x2(t)')

figure
grid on
subplot(3,1,1)
plot(T,x1);
title('Output for subsystem 1 (x1)')
xlabel( 'Time (0.01s)')
ylabel('Amplitude')

subplot(3,1,2)
plot(T,x2);
title('Output for subsystem 2 (x2)')
xlabel( 'Time (0.01s)')
ylabel('Amplitude')

subplot(3,1,3)
plot(T,e);
title('Error e')
xlabel( 'Time (0.01s)')
ylabel('Amplitude')

T=(0:length(t)-1);
figure

plot(T,a1,'-r',T,a2,'-b', 'LineWidth',1.5);
grid on
xlim([0 1500])
title('Adaptation of a1(t) and a2(t)')
xlabel( 'Time (0.01s)')
ylabel('Amp')
legend('a1','a2')
disp('final values of x1,x2,a1,a2')
fprintf('x1: %d \n',x1(5001));
fprintf('x2: %d \n',x2(5001));
fprintf('a1: %d \n',a1(5001));
fprintf('a2: %d \n',a2(5001));